#!/usr/bin/env python3

from 555333 import core

if __name__ == '__main__':
    core.run()
