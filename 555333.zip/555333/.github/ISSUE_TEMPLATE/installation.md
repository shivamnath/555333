---
name: Installation
about: Platform and installation issues
labels: 'installation'

---

Please **DO NOT OPEN** platform and installation issues!
